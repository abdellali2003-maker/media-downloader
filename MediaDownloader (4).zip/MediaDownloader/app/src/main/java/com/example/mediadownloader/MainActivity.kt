package com.example.mediadownloader

import android.Manifest
import android.content.Intent
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

private val Ink = Color(0xFF111111)
private val Bg = Color(0xFFF6F6F6)
private val Muted = Color(0xFF6B6B6B)
private val Line = Color(0xFFE2E2E2)

class MainActivity : ComponentActivity() {

    private var sharedUrl by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val light = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = light, navigationBarStyle = light)
        handleIntent(intent)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink, onPrimary = Color.White,
                    background = Bg, surface = Color.White,
                    outline = Line, outlineVariant = Line,
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Screen(sharedUrl) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            sharedUrl = Regex("https?://\\S+").find(text)?.value ?: text
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(Color.White, RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(sharedUrl: String) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val state by Engine.state.collectAsStateWithLifecycle()

    var url by remember { mutableStateOf("") }
    var audio by remember { mutableStateOf(false) }
    var height by remember { mutableIntStateOf(720) }
    var info by remember { mutableStateOf("") }

    LaunchedEffect(sharedUrl) { if (sharedUrl.isNotBlank()) url = sharedUrl }

    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) { notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ---------- الترويسة ----------
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(48.dp).background(Ink, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) { Text("↓", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
            Column {
                Text("AYZ", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("نزّل الفيديوهات والأغاني بسهولة", fontSize = 13.sp, color = Muted)
            }
        }

        // ---------- الرابط والخيارات ----------
        CardBox {
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                placeholder = { Text("الصق الرابط هنا") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    TextButton(onClick = { clipboard.getText()?.text?.let { url = it.trim() } }) {
                        Text("لصق", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
            )

            Text("النوع", fontSize = 13.sp, color = Muted)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("فيديو", "صوت MP3").forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = (i == 1) == audio,
                        onClick = { audio = i == 1 },
                        shape = SegmentedButtonDefaults.itemShape(i, 2),
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = Ink, activeContentColor = Color.White,
                            inactiveContainerColor = Color.White, inactiveContentColor = Ink,
                        )
                    ) { Text(label) }
                }
            }

            if (!audio) {
                Text("الجودة", fontSize = 13.sp, color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "الأعلى", 1080 to "1080", 720 to "720", 480 to "480").forEach { (h, label) ->
                        FilterChip(
                            selected = height == h, onClick = { height = h },
                            label = { Text(label) },
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Ink, selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            Button(
                onClick = { DownloadService.start(ctx, url.trim(), audio, height) },
                enabled = url.isNotBlank() && !state.running,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
            ) { Text("تنزيل", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        }

        // ---------- الحالة ----------
        if (state.running || state.status.isNotBlank()) {
            CardBox {
                Text(state.status, color = Ink, fontWeight = FontWeight.Medium)
                if (state.running) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = Ink, trackColor = Line,
                    )
                    OutlinedButton(
                        onClick = { DownloadService.cancel(ctx) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("إلغاء", color = Ink) }
                }
            }
        }

        // ---------- أسفل الشاشة ----------
        TextButton(
            onClick = {
                info = "جارٍ التحديث..."
                scope.launch {
                    info = try { Engine.update(ctx) } catch (e: Exception) { "فشل التحديث: ${e.message ?: e.javaClass.simpleName}" }
                }
            },
            enabled = !state.running,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) { Text("تحديث محرّك التنزيل", color = Ink) }
        if (info.isNotBlank()) {
            Text(info, fontSize = 12.sp, color = Muted, modifier = Modifier.align(Alignment.CenterHorizontally))
        }

        Text(
            "للاستخدام الشخصي فقط. حمّل المحتوى الذي تملك حق تنزيله والتزم بشروط المنصات.",
            fontSize = 11.sp, color = Muted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
