package com.example.mediadownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            YoutubeDL.getInstance().destroyProcessById(PROCESS_ID)
            return START_NOT_STICKY
        }
        val url = intent?.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
        val audio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        val height = intent.getIntExtra(EXTRA_HEIGHT, 720)

        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, notification("جارٍ التحضير...", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        scope.launch { download(url, audio, height) }
        return START_NOT_STICKY
    }

    private suspend fun download(url: String, audio: Boolean, height: Int) {
        Engine.state.value = UiState(running = true, status = "جارٍ التحضير...")
        val tmp = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
        try {
            Engine.ensureInit(this)

            val req = YoutubeDLRequest(url).apply {
                addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                addOption("--no-playlist")
                addOption("--restrict-filenames")
                if (audio) {
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "0")
                } else {
                    val f = if (height <= 0) "bv*+ba/b"
                    else "bv*[height<=$height]+ba/b[height<=$height]/b"
                    addOption("-f", f)
                    addOption("--merge-output-format", "mp4")
                }
            }

            YoutubeDL.getInstance().execute(req, PROCESS_ID) { progress, _, _ ->
                val p = progress.coerceIn(0f, 100f)
                Engine.state.value = UiState(true, p / 100f, "جارٍ التنزيل ${p.toInt()}%")
                notify(notification("جارٍ التنزيل ${p.toInt()}%", p.toInt(), false))
            }

            val files = tmp.listFiles()?.filter { it.isFile } ?: emptyList()
            if (files.isEmpty()) error("لم يتم العثور على ملف ناتج")
            files.forEach { saveToDownloads(it) }

            Engine.state.value = UiState(false, 1f, "تم الحفظ في مجلد التنزيلات/MediaDownloader ✅")
            notify(doneNotification("اكتمل التنزيل"))
        } catch (e: Exception) {
            Engine.state.value = UiState(false, 0f, friendlyError(e))
            notify(doneNotification("فشل التنزيل"))
        } finally {
            tmp.deleteRecursively()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private fun saveToDownloads(file: File) {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/MediaDownloader")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("تعذّر إنشاء الملف")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }


    private fun friendlyError(e: Exception): String {
        val raw = e.message ?: e.javaClass.simpleName
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        val main = lines.lastOrNull { it.startsWith("ERROR") } ?: lines.lastOrNull() ?: raw
        val low = raw.lowercase()
        val hint = when {
            "instagram" in low && ("csrf" in low || "login" in low || "cookies" in low || "rate" in low) ->
                "إنستغرام يمنع التنزيل غالباً دون تسجيل دخول. جرّب رابطاً من يوتيوب أو تيك توك، أو حدّث المحرّك ثم أعد المحاولة."
            "unable to resolve host" in low || "network" in low || "timed out" in low ->
                "تعذّر الاتصال بالإنترنت. تأكد من اتصالك وأعد المحاولة."
            "unsupported url" in low -> "هذا الرابط غير مدعوم."
            else -> null
        }
        return "فشل التنزيل" + (hint?.let { "\n$it" } ?: "") + "\n\nالتفاصيل: " + main.take(160)
    }

    // ---------- الإشعارات ----------
    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "التنزيلات", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun notification(text: String, progress: Int, indeterminate: Boolean): Notification {
        val cancel = android.app.PendingIntent.getService(
            this, 0,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setProgress(100, progress, indeterminate)
            .setOngoing(true)
            .addAction(0, "إلغاء", cancel)
            .build()
    }

    private fun doneNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setAutoCancel(true)
            .build()

    private fun notify(n: Notification) =
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)

    override fun onDestroy() { super.onDestroy() }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_HEIGHT = "height"
        const val ACTION_CANCEL = "cancel"
        private const val PROCESS_ID = "main_download"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIF_ID = 1

        fun start(ctx: Context, url: String, audio: Boolean, height: Int) {
            ctx.startForegroundService(
                Intent(ctx, DownloadService::class.java)
                    .putExtra(EXTRA_URL, url)
                    .putExtra(EXTRA_AUDIO, audio)
                    .putExtra(EXTRA_HEIGHT, height)
            )
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, DownloadService::class.java).setAction(ACTION_CANCEL))
        }
    }
}
