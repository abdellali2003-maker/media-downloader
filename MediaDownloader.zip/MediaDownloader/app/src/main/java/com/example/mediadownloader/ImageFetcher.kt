package com.example.mediadownloader

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** تنزيل الصور: رابط صورة مباشر، أو استخراج الصور من صفحة عامة (og:image / twitter:image). */
object ImageFetcher {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private val exts = listOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif")
    private val metaKeys = setOf(
        "og:image", "og:image:secure_url", "og:image:url", "twitter:image", "twitter:image:src"
    )

    private fun cleanPath(url: String) = url.substringBefore('?').substringBefore('#').lowercase()

    fun looksLikeImage(url: String): Boolean = exts.any { cleanPath(url).endsWith(".$it") }

    /** يعيد عدد الصور التي تم حفظها في outDir */
    fun fetch(pageUrl: String, outDir: File): Int {
        val targets = if (looksLikeImage(pageUrl)) listOf(pageUrl) else findImages(pageUrl)
        var saved = 0
        for (u in targets.distinct().take(10)) {
            if (save(u, outDir, saved + 1)) saved++
        }
        return saved
    }

    private fun open(u: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        return c
    }

    private fun resolve(base: String, rel: String): String =
        try { URL(URL(base), rel.replace("&amp;", "&")).toString() } catch (e: Exception) { rel }

    private fun findImages(pageUrl: String): List<String> {
        val html = try {
            open(pageUrl).inputStream.bufferedReader().use { it.readText().take(1_500_000) }
        } catch (e: Exception) {
            return emptyList()
        }
        val out = mutableListOf<String>()
        val keyRe = Regex("(?:property|name)=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
        val contentRe = Regex("content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
        Regex("<meta\\s[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEach { m ->
            val tag = m.value
            val key = keyRe.find(tag)?.groupValues?.get(1)?.lowercase()
            if (key != null && key in metaKeys) {
                contentRe.find(tag)?.groupValues?.get(1)?.let { out += resolve(pageUrl, it) }
            }
        }
        return out
    }

    private fun save(u: String, dir: File, idx: Int): Boolean {
        return try {
            val c = open(u)
            if (c.responseCode !in 200..299) return false
            val type = (c.contentType ?: "").lowercase()
            val urlExt = exts.firstOrNull { cleanPath(u).endsWith(".$it") }
            if (!type.startsWith("image/") && urlExt == null) return false
            val ext = urlExt ?: when {
                "png" in type -> "png"
                "webp" in type -> "webp"
                "gif" in type -> "gif"
                "avif" in type -> "avif"
                else -> "jpg"
            }
            val name = cleanPath(u).substringAfterLast('/').substringBeforeLast('.')
                .replace(Regex("[^a-z0-9_-]"), "_").take(40).ifBlank { "image" }
            val f = File(dir, "${name}_$idx.$ext")
            c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            f.length() > 0
        } catch (e: Exception) {
            false
        }
    }
}
