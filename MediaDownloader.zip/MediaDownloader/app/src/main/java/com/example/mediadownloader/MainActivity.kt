package com.example.mediadownloader

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var sharedUrl by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen(sharedUrl) } } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            // استخراج أول رابط من النص المشارك
            sharedUrl = Regex("https?://\\S+").find(text)?.value ?: text
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(sharedUrl: String) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val state by Engine.state.collectAsStateWithLifecycle()

    var url by remember { mutableStateOf("") }
    var audio by remember { mutableStateOf(false) }
    var height by remember { mutableIntStateOf(720) }
    var info by remember { mutableStateOf("") }

    LaunchedEffect(sharedUrl) { if (sharedUrl.isNotBlank()) url = sharedUrl }

    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) { notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("محمّل الوسائط", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = url, onValueChange = { url = it },
            label = { Text("الصق الرابط هنا") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            trailingIcon = {
                TextButton(onClick = {
                    clipboard.getText()?.text?.let { url = it.trim() }
                }) { Text("لصق") }
            }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !audio, onClick = { audio = false }, label = { Text("فيديو") })
            FilterChip(selected = audio, onClick = { audio = true }, label = { Text("صوت MP3") })
        }

        if (!audio) {
            Text("الجودة", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "الأعلى", 1080 to "1080", 720 to "720", 480 to "480").forEach { (h, label) ->
                    FilterChip(selected = height == h, onClick = { height = h }, label = { Text(label) })
                }
            }
        }

        Button(
            onClick = { DownloadService.start(ctx, url.trim(), audio, height) },
            enabled = url.isNotBlank() && !state.running,
            modifier = Modifier.fillMaxWidth()
        ) { Text("تنزيل") }

        if (state.running) {
            LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { DownloadService.cancel(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("إلغاء")
            }
        }
        if (state.status.isNotBlank()) Text(state.status)

        Spacer(Modifier.weight(1f))

        OutlinedButton(
            onClick = {
                info = "جارٍ التحديث..."
                scope.launch {
                    info = try { Engine.update(ctx) } catch (e: Exception) { "فشل التحديث: ${e.message}" }
                }
            },
            enabled = !state.running,
            modifier = Modifier.fillMaxWidth()
        ) { Text("تحديث محرّك التنزيل (yt-dlp)") }
        if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)

        Text(
            "للاستخدام الشخصي فقط. حمّل المحتوى الذي تملك حق تنزيله والتزم بشروط المنصات.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
