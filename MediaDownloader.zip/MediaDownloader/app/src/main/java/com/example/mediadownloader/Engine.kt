package com.example.mediadownloader

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow

data class UiState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val status: String = "",
)

/** حالة مشتركة بين الخدمة والواجهة + تهيئة yt-dlp مرة واحدة */
object Engine {
    val state = MutableStateFlow(UiState())
    private val mutex = Mutex()
    private var ready = false

    suspend fun ensureInit(ctx: Context) = mutex.withLock {
        if (!ready) {
            YoutubeDL.getInstance().init(ctx.applicationContext)
            FFmpeg.getInstance().init(ctx.applicationContext)
            ready = true
        }
    }

    suspend fun update(ctx: Context): String {
        ensureInit(ctx)
        val r = YoutubeDL.getInstance()
            .updateYoutubeDL(ctx.applicationContext, YoutubeDL.UpdateChannel.STABLE)
        return when (r) {
            YoutubeDL.UpdateStatus.DONE -> "تم التحديث بنجاح"
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "أنت على آخر إصدار"
            else -> "تم التحقق من التحديثات"
        }
    }
}
